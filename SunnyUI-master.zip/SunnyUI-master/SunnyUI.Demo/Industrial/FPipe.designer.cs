﻿
namespace Sunny.UI.Demo
{
    partial class FPipe
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.uiPipe3 = new Sunny.UI.UIPipe();
            this.uiPipe4 = new Sunny.UI.UIPipe();
            this.uiPipe2 = new Sunny.UI.UIPipe();
            this.uiPipe7 = new Sunny.UI.UIPipe();
            this.uiPipe8 = new Sunny.UI.UIPipe();
            this.uiPipe9 = new Sunny.UI.UIPipe();
            this.uiPipe10 = new Sunny.UI.UIPipe();
            this.uiPipe11 = new Sunny.UI.UIPipe();
            this.uiPipe12 = new Sunny.UI.UIPipe();
            this.uiPipe1 = new Sunny.UI.UIPipe();
            this.uiPipe5 = new Sunny.UI.UIPipe();
            this.uiPipe6 = new Sunny.UI.UIPipe();
            this.uiPipe13 = new Sunny.UI.UIPipe();
            this.uiPipe14 = new Sunny.UI.UIPipe();
            this.uiPipe15 = new Sunny.UI.UIPipe();
            this.uiPipe16 = new Sunny.UI.UIPipe();
            this.uiPipe17 = new Sunny.UI.UIPipe();
            this.uiPipe18 = new Sunny.UI.UIPipe();
            this.uiValve1 = new Sunny.UI.UIValve();
            this.uiPipe19 = new Sunny.UI.UIPipe();
            this.uiValve2 = new Sunny.UI.UIValve();
            this.uiValve3 = new Sunny.UI.UIValve();
            this.uiValve4 = new Sunny.UI.UIValve();
            this.uiPipe20 = new Sunny.UI.UIPipe();
            this.uiPipe21 = new Sunny.UI.UIPipe();
            this.uiPipe22 = new Sunny.UI.UIPipe();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 200;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // uiPipe3
            // 
            this.uiPipe3.Active = true;
            this.uiPipe3.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe3.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe3.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.uiPipe3.FlowSpeed = 10;
            this.uiPipe3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe3.Location = new System.Drawing.Point(196, 194);
            this.uiPipe3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe3.Name = "uiPipe3";
            this.uiPipe3.Radius = 16;
            this.uiPipe3.RadiusSides = Sunny.UI.UICornerRadiusSides.RightTop;
            this.uiPipe3.Size = new System.Drawing.Size(16, 234);
            this.uiPipe3.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe3.StyleCustomMode = true;
            this.uiPipe3.TabIndex = 9;
            this.uiPipe3.Text = "uiPipe3";
            // 
            // uiPipe4
            // 
            this.uiPipe4.Active = true;
            this.uiPipe4.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe4.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe4.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.uiPipe4.FlowSpeed = 10;
            this.uiPipe4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe4.Location = new System.Drawing.Point(34, 63);
            this.uiPipe4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe4.Name = "uiPipe4";
            this.uiPipe4.Radius = 16;
            this.uiPipe4.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe4.Size = new System.Drawing.Size(16, 365);
            this.uiPipe4.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe4.StyleCustomMode = true;
            this.uiPipe4.TabIndex = 8;
            this.uiPipe4.Text = "uiPipe4";
            // 
            // uiPipe2
            // 
            this.uiPipe2.Active = true;
            this.uiPipe2.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe2.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.uiPipe2.FlowSpeed = 10;
            this.uiPipe2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe2.Location = new System.Drawing.Point(48, 194);
            this.uiPipe2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe2.Name = "uiPipe2";
            this.uiPipe2.Radius = 16;
            this.uiPipe2.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe2.Size = new System.Drawing.Size(73, 16);
            this.uiPipe2.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe2.StyleCustomMode = true;
            this.uiPipe2.TabIndex = 5;
            this.uiPipe2.Text = "uiPipe2";
            // 
            // uiPipe7
            // 
            this.uiPipe7.Active = true;
            this.uiPipe7.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe7.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe7.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.uiPipe7.FlowSpeed = 10;
            this.uiPipe7.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe7.Location = new System.Drawing.Point(451, 194);
            this.uiPipe7.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe7.Name = "uiPipe7";
            this.uiPipe7.Radius = 16;
            this.uiPipe7.RadiusSides = ((Sunny.UI.UICornerRadiusSides)((Sunny.UI.UICornerRadiusSides.RightTop | Sunny.UI.UICornerRadiusSides.RightBottom)));
            this.uiPipe7.Size = new System.Drawing.Size(16, 73);
            this.uiPipe7.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe7.StyleCustomMode = true;
            this.uiPipe7.TabIndex = 14;
            this.uiPipe7.Text = "uiPipe7";
            // 
            // uiPipe8
            // 
            this.uiPipe8.Active = true;
            this.uiPipe8.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe8.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe8.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.uiPipe8.FlowSpeed = 10;
            this.uiPipe8.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe8.Location = new System.Drawing.Point(289, 175);
            this.uiPipe8.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe8.Name = "uiPipe8";
            this.uiPipe8.Radius = 16;
            this.uiPipe8.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe8.Size = new System.Drawing.Size(16, 253);
            this.uiPipe8.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe8.StyleCustomMode = true;
            this.uiPipe8.TabIndex = 13;
            this.uiPipe8.Text = "uiPipe8";
            // 
            // uiPipe9
            // 
            this.uiPipe9.Active = true;
            this.uiPipe9.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe9.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.uiPipe9.FlowSpeed = 10;
            this.uiPipe9.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe9.Location = new System.Drawing.Point(303, 194);
            this.uiPipe9.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe9.Name = "uiPipe9";
            this.uiPipe9.Radius = 16;
            this.uiPipe9.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe9.Size = new System.Drawing.Size(149, 16);
            this.uiPipe9.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe9.StyleCustomMode = true;
            this.uiPipe9.TabIndex = 12;
            this.uiPipe9.Text = "uiPipe9";
            // 
            // uiPipe10
            // 
            this.uiPipe10.Active = true;
            this.uiPipe10.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe10.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.uiPipe10.FlowDirection = Sunny.UI.UIPipe.UIFlowDirection.Reverse;
            this.uiPipe10.FlowSpeed = 10;
            this.uiPipe10.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe10.Location = new System.Drawing.Point(78, 251);
            this.uiPipe10.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe10.Name = "uiPipe10";
            this.uiPipe10.Radius = 16;
            this.uiPipe10.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe10.Size = new System.Drawing.Size(389, 16);
            this.uiPipe10.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe10.StyleCustomMode = true;
            this.uiPipe10.TabIndex = 15;
            this.uiPipe10.Text = "uiPipe10";
            // 
            // uiPipe11
            // 
            this.uiPipe11.Active = true;
            this.uiPipe11.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe11.FlowColor = System.Drawing.Color.SkyBlue;
            this.uiPipe11.FlowDirection = Sunny.UI.UIPipe.UIFlowDirection.Reverse;
            this.uiPipe11.FlowSpeed = 10;
            this.uiPipe11.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe11.Location = new System.Drawing.Point(109, 295);
            this.uiPipe11.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe11.Name = "uiPipe11";
            this.uiPipe11.Radius = 16;
            this.uiPipe11.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe11.Size = new System.Drawing.Size(612, 16);
            this.uiPipe11.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe11.StyleCustomMode = true;
            this.uiPipe11.TabIndex = 16;
            this.uiPipe11.Text = "uiPipe11";
            // 
            // uiPipe12
            // 
            this.uiPipe12.Active = true;
            this.uiPipe12.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe12.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe12.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.uiPipe12.FlowSpeed = 10;
            this.uiPipe12.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe12.Location = new System.Drawing.Point(63, 251);
            this.uiPipe12.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe12.Name = "uiPipe12";
            this.uiPipe12.Radius = 16;
            this.uiPipe12.RadiusSides = Sunny.UI.UICornerRadiusSides.LeftTop;
            this.uiPipe12.Size = new System.Drawing.Size(16, 114);
            this.uiPipe12.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe12.StyleCustomMode = true;
            this.uiPipe12.TabIndex = 17;
            this.uiPipe12.Text = "uiPipe12";
            // 
            // uiPipe1
            // 
            this.uiPipe1.Active = true;
            this.uiPipe1.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe1.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe1.FlowColor = System.Drawing.Color.SkyBlue;
            this.uiPipe1.FlowSpeed = 10;
            this.uiPipe1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe1.Location = new System.Drawing.Point(94, 295);
            this.uiPipe1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe1.Name = "uiPipe1";
            this.uiPipe1.Radius = 16;
            this.uiPipe1.RadiusSides = Sunny.UI.UICornerRadiusSides.LeftTop;
            this.uiPipe1.Size = new System.Drawing.Size(16, 70);
            this.uiPipe1.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe1.StyleCustomMode = true;
            this.uiPipe1.TabIndex = 18;
            this.uiPipe1.Text = "uiPipe1";
            // 
            // uiPipe5
            // 
            this.uiPipe5.Active = true;
            this.uiPipe5.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe5.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe5.FlowColor = System.Drawing.Color.SkyBlue;
            this.uiPipe5.FlowSpeed = 10;
            this.uiPipe5.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe5.Location = new System.Drawing.Point(716, 175);
            this.uiPipe5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe5.Name = "uiPipe5";
            this.uiPipe5.Radius = 16;
            this.uiPipe5.RadiusSides = Sunny.UI.UICornerRadiusSides.RightBottom;
            this.uiPipe5.Size = new System.Drawing.Size(16, 136);
            this.uiPipe5.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe5.StyleCustomMode = true;
            this.uiPipe5.TabIndex = 19;
            this.uiPipe5.Text = "uiPipe5";
            // 
            // uiPipe6
            // 
            this.uiPipe6.Active = true;
            this.uiPipe6.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe6.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe6.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.uiPipe6.FlowInterval = 16;
            this.uiPipe6.FlowSize = 28;
            this.uiPipe6.FlowSpeed = 12;
            this.uiPipe6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe6.Location = new System.Drawing.Point(63, 384);
            this.uiPipe6.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe6.Name = "uiPipe6";
            this.uiPipe6.Radius = 16;
            this.uiPipe6.RadiusSides = Sunny.UI.UICornerRadiusSides.LeftBottom;
            this.uiPipe6.RectColor = System.Drawing.Color.DarkGray;
            this.uiPipe6.Size = new System.Drawing.Size(16, 156);
            this.uiPipe6.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe6.StyleCustomMode = true;
            this.uiPipe6.TabIndex = 20;
            this.uiPipe6.Text = "uiPipe6";
            // 
            // uiPipe13
            // 
            this.uiPipe13.Active = true;
            this.uiPipe13.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe13.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.uiPipe13.FlowInterval = 16;
            this.uiPipe13.FlowSize = 28;
            this.uiPipe13.FlowSpeed = 12;
            this.uiPipe13.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe13.Location = new System.Drawing.Point(77, 483);
            this.uiPipe13.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe13.Name = "uiPipe13";
            this.uiPipe13.Radius = 16;
            this.uiPipe13.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe13.RectColor = System.Drawing.Color.DarkGray;
            this.uiPipe13.Size = new System.Drawing.Size(643, 16);
            this.uiPipe13.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe13.StyleCustomMode = true;
            this.uiPipe13.TabIndex = 21;
            this.uiPipe13.Text = "uiPipe13";
            // 
            // uiPipe14
            // 
            this.uiPipe14.Active = true;
            this.uiPipe14.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe14.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.uiPipe14.FlowInterval = 16;
            this.uiPipe14.FlowSize = 28;
            this.uiPipe14.FlowSpeed = 12;
            this.uiPipe14.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe14.Location = new System.Drawing.Point(77, 524);
            this.uiPipe14.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe14.Name = "uiPipe14";
            this.uiPipe14.Radius = 16;
            this.uiPipe14.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe14.RectColor = System.Drawing.Color.DarkGray;
            this.uiPipe14.Size = new System.Drawing.Size(134, 16);
            this.uiPipe14.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe14.StyleCustomMode = true;
            this.uiPipe14.TabIndex = 22;
            this.uiPipe14.Text = "uiPipe14";
            // 
            // uiPipe15
            // 
            this.uiPipe15.Active = true;
            this.uiPipe15.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe15.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe15.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.uiPipe15.FlowDirection = Sunny.UI.UIPipe.UIFlowDirection.Reverse;
            this.uiPipe15.FlowInterval = 16;
            this.uiPipe15.FlowSize = 28;
            this.uiPipe15.FlowSpeed = 12;
            this.uiPipe15.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe15.Location = new System.Drawing.Point(374, 384);
            this.uiPipe15.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe15.Name = "uiPipe15";
            this.uiPipe15.Radius = 16;
            this.uiPipe15.RadiusSides = Sunny.UI.UICornerRadiusSides.RightBottom;
            this.uiPipe15.RectColor = System.Drawing.Color.DarkGray;
            this.uiPipe15.Size = new System.Drawing.Size(16, 156);
            this.uiPipe15.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe15.StyleCustomMode = true;
            this.uiPipe15.TabIndex = 23;
            this.uiPipe15.Text = "uiPipe15";
            // 
            // uiPipe16
            // 
            this.uiPipe16.Active = true;
            this.uiPipe16.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe16.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe16.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.uiPipe16.FlowInterval = 16;
            this.uiPipe16.FlowSize = 28;
            this.uiPipe16.FlowSpeed = 12;
            this.uiPipe16.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiPipe16.Location = new System.Drawing.Point(536, 384);
            this.uiPipe16.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe16.Name = "uiPipe16";
            this.uiPipe16.Radius = 16;
            this.uiPipe16.RadiusSides = Sunny.UI.UICornerRadiusSides.LeftBottom;
            this.uiPipe16.RectColor = System.Drawing.Color.DarkGray;
            this.uiPipe16.Size = new System.Drawing.Size(16, 83);
            this.uiPipe16.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe16.StyleCustomMode = true;
            this.uiPipe16.TabIndex = 24;
            this.uiPipe16.Text = "uiPipe16";
            // 
            // uiPipe17
            // 
            this.uiPipe17.Active = true;
            this.uiPipe17.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe17.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.uiPipe17.FlowInterval = 16;
            this.uiPipe17.FlowSize = 28;
            this.uiPipe17.FlowSpeed = 12;
            this.uiPipe17.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiPipe17.Location = new System.Drawing.Point(551, 451);
            this.uiPipe17.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe17.Name = "uiPipe17";
            this.uiPipe17.Radius = 16;
            this.uiPipe17.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe17.RectColor = System.Drawing.Color.DarkGray;
            this.uiPipe17.Size = new System.Drawing.Size(169, 16);
            this.uiPipe17.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe17.StyleCustomMode = true;
            this.uiPipe17.TabIndex = 25;
            this.uiPipe17.Text = "uiPipe17";
            // 
            // uiPipe18
            // 
            this.uiPipe18.Active = true;
            this.uiPipe18.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe18.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe18.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.uiPipe18.FlowInterval = 16;
            this.uiPipe18.FlowSize = 28;
            this.uiPipe18.FlowSpeed = 12;
            this.uiPipe18.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.uiPipe18.Location = new System.Drawing.Point(716, 451);
            this.uiPipe18.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe18.Name = "uiPipe18";
            this.uiPipe18.Radius = 16;
            this.uiPipe18.RadiusSides = Sunny.UI.UICornerRadiusSides.RightTop;
            this.uiPipe18.RectColor = System.Drawing.Color.DarkGray;
            this.uiPipe18.Size = new System.Drawing.Size(16, 89);
            this.uiPipe18.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe18.StyleCustomMode = true;
            this.uiPipe18.TabIndex = 26;
            this.uiPipe18.Text = "uiPipe18";
            // 
            // uiValve1
            // 
            this.uiValve1.Active = true;
            this.uiValve1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiValve1.Location = new System.Drawing.Point(255, 122);
            this.uiValve1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiValve1.Name = "uiValve1";
            this.uiValve1.PipeSize = 20;
            this.uiValve1.Size = new System.Drawing.Size(60, 60);
            this.uiValve1.TabIndex = 27;
            this.uiValve1.Text = "uiValve1";
            this.uiValve1.ValveColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.uiValve1.ActiveChanged += new System.EventHandler(this.uiValve1_ActiveChanged);
            // 
            // uiPipe19
            // 
            this.uiPipe19.Active = true;
            this.uiPipe19.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe19.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe19.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.uiPipe19.FlowSpeed = 10;
            this.uiPipe19.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe19.Location = new System.Drawing.Point(289, 63);
            this.uiPipe19.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe19.Name = "uiPipe19";
            this.uiPipe19.Radius = 16;
            this.uiPipe19.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe19.Size = new System.Drawing.Size(16, 74);
            this.uiPipe19.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe19.StyleCustomMode = true;
            this.uiPipe19.TabIndex = 28;
            this.uiPipe19.Text = "uiPipe19";
            // 
            // uiValve2
            // 
            this.uiValve2.Active = true;
            this.uiValve2.Direction = Sunny.UI.UIValve.UIValveDirection.Right;
            this.uiValve2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiValve2.Location = new System.Drawing.Point(706, 122);
            this.uiValve2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiValve2.Name = "uiValve2";
            this.uiValve2.PipeSize = 20;
            this.uiValve2.Size = new System.Drawing.Size(60, 60);
            this.uiValve2.TabIndex = 29;
            this.uiValve2.Text = "uiValve2";
            this.uiValve2.ActiveChanged += new System.EventHandler(this.uiValve2_ActiveChanged);
            // 
            // uiValve3
            // 
            this.uiValve3.Active = true;
            this.uiValve3.Direction = Sunny.UI.UIValve.UIValveDirection.Top;
            this.uiValve3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiValve3.Location = new System.Drawing.Point(94, 160);
            this.uiValve3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiValve3.Name = "uiValve3";
            this.uiValve3.PipeSize = 20;
            this.uiValve3.Size = new System.Drawing.Size(60, 60);
            this.uiValve3.TabIndex = 30;
            this.uiValve3.Text = "uiValve3";
            this.uiValve3.ValveColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.uiValve3.ActiveChanged += new System.EventHandler(this.uiValve3_ActiveChanged);
            // 
            // uiValve4
            // 
            this.uiValve4.Active = true;
            this.uiValve4.Direction = Sunny.UI.UIValve.UIValveDirection.Bottom;
            this.uiValve4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiValve4.Location = new System.Drawing.Point(186, 514);
            this.uiValve4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiValve4.Name = "uiValve4";
            this.uiValve4.PipeSize = 20;
            this.uiValve4.RectColor = System.Drawing.Color.DarkGray;
            this.uiValve4.Size = new System.Drawing.Size(60, 60);
            this.uiValve4.TabIndex = 31;
            this.uiValve4.Text = "uiValve4";
            this.uiValve4.ValveColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.uiValve4.ActiveChanged += new System.EventHandler(this.uiValve4_ActiveChanged);
            // 
            // uiPipe20
            // 
            this.uiPipe20.Active = true;
            this.uiPipe20.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe20.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.uiPipe20.FlowSpeed = 10;
            this.uiPipe20.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe20.Location = new System.Drawing.Point(124, 194);
            this.uiPipe20.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe20.Name = "uiPipe20";
            this.uiPipe20.Radius = 16;
            this.uiPipe20.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe20.Size = new System.Drawing.Size(73, 16);
            this.uiPipe20.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe20.StyleCustomMode = true;
            this.uiPipe20.TabIndex = 32;
            this.uiPipe20.Text = "uiPipe20";
            // 
            // uiPipe21
            // 
            this.uiPipe21.Active = true;
            this.uiPipe21.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe21.Direction = Sunny.UI.UILine.LineDirection.Vertical;
            this.uiPipe21.FlowColor = System.Drawing.Color.SkyBlue;
            this.uiPipe21.FlowSpeed = 10;
            this.uiPipe21.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe21.Location = new System.Drawing.Point(716, 63);
            this.uiPipe21.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe21.Name = "uiPipe21";
            this.uiPipe21.Radius = 16;
            this.uiPipe21.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe21.Size = new System.Drawing.Size(16, 74);
            this.uiPipe21.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe21.StyleCustomMode = true;
            this.uiPipe21.TabIndex = 33;
            this.uiPipe21.Text = "uiPipe21";
            // 
            // uiPipe22
            // 
            this.uiPipe22.Active = true;
            this.uiPipe22.BackColor = System.Drawing.Color.Transparent;
            this.uiPipe22.FlowColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.uiPipe22.FlowInterval = 16;
            this.uiPipe22.FlowSize = 28;
            this.uiPipe22.FlowSpeed = 12;
            this.uiPipe22.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPipe22.Location = new System.Drawing.Point(242, 524);
            this.uiPipe22.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPipe22.Name = "uiPipe22";
            this.uiPipe22.Radius = 16;
            this.uiPipe22.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiPipe22.RectColor = System.Drawing.Color.DarkGray;
            this.uiPipe22.Size = new System.Drawing.Size(134, 16);
            this.uiPipe22.Style = Sunny.UI.UIStyle.Custom;
            this.uiPipe22.StyleCustomMode = true;
            this.uiPipe22.TabIndex = 34;
            this.uiPipe22.Text = "uiPipe22";
            // 
            // FPipe
            // 
            this.AllowShowTitle = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(855, 642);
            this.Controls.Add(this.uiValve4);
            this.Controls.Add(this.uiValve2);
            this.Controls.Add(this.uiPipe21);
            this.Controls.Add(this.uiPipe3);
            this.Controls.Add(this.uiValve3);
            this.Controls.Add(this.uiPipe20);
            this.Controls.Add(this.uiValve1);
            this.Controls.Add(this.uiPipe19);
            this.Controls.Add(this.uiPipe18);
            this.Controls.Add(this.uiPipe16);
            this.Controls.Add(this.uiPipe15);
            this.Controls.Add(this.uiPipe6);
            this.Controls.Add(this.uiPipe5);
            this.Controls.Add(this.uiPipe1);
            this.Controls.Add(this.uiPipe12);
            this.Controls.Add(this.uiPipe7);
            this.Controls.Add(this.uiPipe8);
            this.Controls.Add(this.uiPipe9);
            this.Controls.Add(this.uiPipe4);
            this.Controls.Add(this.uiPipe2);
            this.Controls.Add(this.uiPipe10);
            this.Controls.Add(this.uiPipe11);
            this.Controls.Add(this.uiPipe14);
            this.Controls.Add(this.uiPipe17);
            this.Controls.Add(this.uiPipe13);
            this.Controls.Add(this.uiPipe22);
            this.Name = "FPipe";
            this.Padding = new System.Windows.Forms.Padding(0, 35, 0, 0);
            this.ShowTitle = true;
            this.Symbol = 61860;
            this.Text = "Pipe";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private UIPipe uiPipe2;
        private UIPipe uiPipe4;
        private UIPipe uiPipe3;
        private UIPipe uiPipe7;
        private UIPipe uiPipe8;
        private UIPipe uiPipe9;
        private UIPipe uiPipe10;
        private UIPipe uiPipe11;
        private UIPipe uiPipe12;
        private UIPipe uiPipe1;
        private UIPipe uiPipe5;
        private UIPipe uiPipe6;
        private UIPipe uiPipe13;
        private UIPipe uiPipe14;
        private UIPipe uiPipe15;
        private UIPipe uiPipe16;
        private UIPipe uiPipe17;
        private UIPipe uiPipe18;
        private UIValve uiValve1;
        private UIPipe uiPipe19;
        private UIValve uiValve2;
        private UIValve uiValve3;
        private UIValve uiValve4;
        private UIPipe uiPipe20;
        private UIPipe uiPipe21;
        private UIPipe uiPipe22;
    }
}

