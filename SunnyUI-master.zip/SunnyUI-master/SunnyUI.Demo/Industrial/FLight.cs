﻿namespace Sunny.UI.Demo
{
    public partial class FLight : UIPage
    {
        public FLight()
        {
            InitializeComponent();
        }
    }
}
