﻿
namespace Sunny.UI.Demo
{
    partial class FOther
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.uiLabel3 = new Sunny.UI.UILabel();
            this.uiLabel2 = new Sunny.UI.UILabel();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.uiLine7 = new Sunny.UI.UILine();
            this.uiScrollingText2 = new Sunny.UI.UIScrollingText();
            this.uiScrollingText1 = new Sunny.UI.UIScrollingText();
            this.uiLine6 = new Sunny.UI.UILine();
            this.uiToolTip1 = new Sunny.UI.UIToolTip(this.components);
            this.uiLine1 = new Sunny.UI.UILine();
            this.uiVerificationCode1 = new Sunny.UI.UIVerificationCode();
            this.uiVerificationCode2 = new Sunny.UI.UIVerificationCode();
            this.uiCalendar1 = new Sunny.UI.UICalendar();
            this.uiLine2 = new Sunny.UI.UILine();
            this.SuspendLayout();
            // 
            // uiLabel3
            // 
            this.uiLabel3.AutoSize = true;
            this.uiLabel3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel3.Location = new System.Drawing.Point(31, 136);
            this.uiLabel3.Name = "uiLabel3";
            this.uiLabel3.Size = new System.Drawing.Size(138, 21);
            this.uiLabel3.TabIndex = 79;
            this.uiLabel3.Text = "鼠标移过来看提示";
            this.uiLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel2
            // 
            this.uiLabel2.AutoSize = true;
            this.uiLabel2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel2.Location = new System.Drawing.Point(211, 95);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Size = new System.Drawing.Size(138, 21);
            this.uiLabel2.TabIndex = 78;
            this.uiLabel2.Text = "鼠标移过来看提示";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLabel1
            // 
            this.uiLabel1.AutoSize = true;
            this.uiLabel1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel1.Location = new System.Drawing.Point(31, 95);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(138, 21);
            this.uiLabel1.TabIndex = 77;
            this.uiLabel1.Text = "鼠标移过来看提示";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiToolTip1.SetToolTip(this.uiLabel1, "赠人玫瑰手有余香");
            // 
            // uiLine7
            // 
            this.uiLine7.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine7.Location = new System.Drawing.Point(30, 55);
            this.uiLine7.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine7.Name = "uiLine7";
            this.uiLine7.Size = new System.Drawing.Size(319, 20);
            this.uiLine7.TabIndex = 76;
            this.uiLine7.Text = "UIToolTip";
            this.uiLine7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiScrollingText2
            // 
            this.uiScrollingText2.Active = true;
            this.uiScrollingText2.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiScrollingText2.Location = new System.Drawing.Point(381, 129);
            this.uiScrollingText2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiScrollingText2.Name = "uiScrollingText2";
            this.uiScrollingText2.Size = new System.Drawing.Size(319, 35);
            this.uiScrollingText2.TabIndex = 75;
            this.uiScrollingText2.Text = "赠人玫瑰手有余香";
            // 
            // uiScrollingText1
            // 
            this.uiScrollingText1.Active = true;
            this.uiScrollingText1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(243)))), ((int)(((byte)(255)))));
            this.uiScrollingText1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiScrollingText1.ForeColor = System.Drawing.Color.Red;
            this.uiScrollingText1.Location = new System.Drawing.Point(381, 88);
            this.uiScrollingText1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiScrollingText1.Name = "uiScrollingText1";
            this.uiScrollingText1.ScrollingType = Sunny.UI.UIScrollingText.UIScrollingType.LeftToRight;
            this.uiScrollingText1.Size = new System.Drawing.Size(319, 35);
            this.uiScrollingText1.Style = Sunny.UI.UIStyle.Custom;
            this.uiScrollingText1.StyleCustomMode = true;
            this.uiScrollingText1.TabIndex = 74;
            this.uiScrollingText1.Text = "赠人玫瑰手有余香";
            // 
            // uiLine6
            // 
            this.uiLine6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine6.Location = new System.Drawing.Point(381, 55);
            this.uiLine6.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine6.Name = "uiLine6";
            this.uiLine6.Size = new System.Drawing.Size(319, 20);
            this.uiLine6.TabIndex = 73;
            this.uiLine6.Text = "UIScrollingText";
            this.uiLine6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiToolTip1
            // 
            this.uiToolTip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.uiToolTip1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiToolTip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.uiToolTip1.OwnerDraw = true;
            this.uiToolTip1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            // 
            // uiLine1
            // 
            this.uiLine1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine1.Location = new System.Drawing.Point(381, 187);
            this.uiLine1.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(319, 20);
            this.uiLine1.TabIndex = 80;
            this.uiLine1.Text = "UIVerificationCode";
            this.uiLine1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiVerificationCode1
            // 
            this.uiVerificationCode1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiVerificationCode1.Location = new System.Drawing.Point(381, 225);
            this.uiVerificationCode1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiVerificationCode1.Name = "uiVerificationCode1";
            this.uiVerificationCode1.Size = new System.Drawing.Size(100, 35);
            this.uiVerificationCode1.TabIndex = 81;
            // 
            // uiVerificationCode2
            // 
            this.uiVerificationCode2.CodeLength = 6;
            this.uiVerificationCode2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiVerificationCode2.Location = new System.Drawing.Point(499, 225);
            this.uiVerificationCode2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiVerificationCode2.Name = "uiVerificationCode2";
            this.uiVerificationCode2.Size = new System.Drawing.Size(140, 35);
            this.uiVerificationCode2.TabIndex = 82;
            // 
            // uiCalendar1
            // 
            this.uiCalendar1.Date = new System.DateTime(2022, 7, 3, 0, 0, 0, 0);
            this.uiCalendar1.FillColor = System.Drawing.Color.White;
            this.uiCalendar1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiCalendar1.Location = new System.Drawing.Point(30, 225);
            this.uiCalendar1.MinimumSize = new System.Drawing.Size(240, 180);
            this.uiCalendar1.Name = "uiCalendar1";
            this.uiCalendar1.PrimaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(160)))), ((int)(((byte)(255)))));
            this.uiCalendar1.Size = new System.Drawing.Size(319, 240);
            this.uiCalendar1.TabIndex = 83;
            this.uiCalendar1.Text = "uiCalendar1";
            this.uiCalendar1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiCalendar1.OnDateTimeChanged += new Sunny.UI.OnDateTimeChanged(this.uiCalendar1_OnDateTimeChanged);
            // 
            // uiLine2
            // 
            this.uiLine2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine2.Location = new System.Drawing.Point(30, 187);
            this.uiLine2.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine2.Name = "uiLine2";
            this.uiLine2.Size = new System.Drawing.Size(319, 20);
            this.uiLine2.TabIndex = 84;
            this.uiLine2.Text = "UICalendar";
            this.uiLine2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FOther
            // 
            this.AllowShowTitle = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.uiLine2);
            this.Controls.Add(this.uiCalendar1);
            this.Controls.Add(this.uiVerificationCode2);
            this.Controls.Add(this.uiVerificationCode1);
            this.Controls.Add(this.uiLine1);
            this.Controls.Add(this.uiLabel3);
            this.Controls.Add(this.uiLabel2);
            this.Controls.Add(this.uiLabel1);
            this.Controls.Add(this.uiLine7);
            this.Controls.Add(this.uiScrollingText2);
            this.Controls.Add(this.uiScrollingText1);
            this.Controls.Add(this.uiLine6);
            this.Name = "FOther";
            this.Padding = new System.Windows.Forms.Padding(0, 35, 0, 0);
            this.ShowTitle = true;
            this.Symbol = 62173;
            this.Text = "Other";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private UILabel uiLabel3;
        private UILabel uiLabel2;
        private UILabel uiLabel1;
        private UILine uiLine7;
        private UIScrollingText uiScrollingText2;
        private UIScrollingText uiScrollingText1;
        private UILine uiLine6;
        private UIToolTip uiToolTip1;
        private UILine uiLine1;
        private UIVerificationCode uiVerificationCode1;
        private UIVerificationCode uiVerificationCode2;
        private UICalendar uiCalendar1;
        private UILine uiLine2;
    }
}