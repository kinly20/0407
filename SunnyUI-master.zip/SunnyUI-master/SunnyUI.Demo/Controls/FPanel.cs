﻿namespace Sunny.UI.Demo
{
    public partial class FPanel : UIPage
    {
        public FPanel()
        {
            InitializeComponent();
        }
    }
}
