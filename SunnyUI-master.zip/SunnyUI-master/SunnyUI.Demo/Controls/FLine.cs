﻿namespace Sunny.UI.Demo
{
    public partial class FLine : UIPage
    {
        public FLine()
        {
            InitializeComponent();
        }
    }
}
