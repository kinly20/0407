﻿
namespace Sunny.UI.Demo
{
    partial class FCombobox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode65 = new System.Windows.Forms.TreeNode("节点0");
            System.Windows.Forms.TreeNode treeNode66 = new System.Windows.Forms.TreeNode("节点1");
            System.Windows.Forms.TreeNode treeNode67 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode68 = new System.Windows.Forms.TreeNode("节点3");
            System.Windows.Forms.TreeNode treeNode69 = new System.Windows.Forms.TreeNode("节点0", new System.Windows.Forms.TreeNode[] {
            treeNode65,
            treeNode66,
            treeNode67,
            treeNode68});
            System.Windows.Forms.TreeNode treeNode70 = new System.Windows.Forms.TreeNode("节点4");
            System.Windows.Forms.TreeNode treeNode71 = new System.Windows.Forms.TreeNode("节点5");
            System.Windows.Forms.TreeNode treeNode72 = new System.Windows.Forms.TreeNode("节点6");
            System.Windows.Forms.TreeNode treeNode73 = new System.Windows.Forms.TreeNode("节点7");
            System.Windows.Forms.TreeNode treeNode74 = new System.Windows.Forms.TreeNode("节点1", new System.Windows.Forms.TreeNode[] {
            treeNode70,
            treeNode71,
            treeNode72,
            treeNode73});
            System.Windows.Forms.TreeNode treeNode75 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode76 = new System.Windows.Forms.TreeNode("节点3");
            System.Windows.Forms.TreeNode treeNode77 = new System.Windows.Forms.TreeNode("节点00");
            System.Windows.Forms.TreeNode treeNode78 = new System.Windows.Forms.TreeNode("节点01");
            System.Windows.Forms.TreeNode treeNode79 = new System.Windows.Forms.TreeNode("节点02");
            System.Windows.Forms.TreeNode treeNode80 = new System.Windows.Forms.TreeNode("节点03");
            System.Windows.Forms.TreeNode treeNode81 = new System.Windows.Forms.TreeNode("节点0", new System.Windows.Forms.TreeNode[] {
            treeNode77,
            treeNode78,
            treeNode79,
            treeNode80});
            System.Windows.Forms.TreeNode treeNode82 = new System.Windows.Forms.TreeNode("节点11");
            System.Windows.Forms.TreeNode treeNode83 = new System.Windows.Forms.TreeNode("节点12");
            System.Windows.Forms.TreeNode treeNode84 = new System.Windows.Forms.TreeNode("节点13");
            System.Windows.Forms.TreeNode treeNode85 = new System.Windows.Forms.TreeNode("节点14");
            System.Windows.Forms.TreeNode treeNode86 = new System.Windows.Forms.TreeNode("节点1", new System.Windows.Forms.TreeNode[] {
            treeNode82,
            treeNode83,
            treeNode84,
            treeNode85});
            System.Windows.Forms.TreeNode treeNode87 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode88 = new System.Windows.Forms.TreeNode("节点3");
            System.Windows.Forms.TreeNode treeNode89 = new System.Windows.Forms.TreeNode("节点0");
            System.Windows.Forms.TreeNode treeNode90 = new System.Windows.Forms.TreeNode("节点1");
            System.Windows.Forms.TreeNode treeNode91 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode92 = new System.Windows.Forms.TreeNode("节点3");
            System.Windows.Forms.TreeNode treeNode93 = new System.Windows.Forms.TreeNode("节点0");
            System.Windows.Forms.TreeNode treeNode94 = new System.Windows.Forms.TreeNode("节点1");
            System.Windows.Forms.TreeNode treeNode95 = new System.Windows.Forms.TreeNode("节点2");
            System.Windows.Forms.TreeNode treeNode96 = new System.Windows.Forms.TreeNode("节点3");
            this.uiComboTreeView3 = new Sunny.UI.UIComboTreeView();
            this.uiComboTreeView4 = new Sunny.UI.UIComboTreeView();
            this.uiComboTreeView2 = new Sunny.UI.UIComboTreeView();
            this.uiLine1 = new Sunny.UI.UILine();
            this.uiComboTreeView1 = new Sunny.UI.UIComboTreeView();
            this.uiLine8 = new Sunny.UI.UILine();
            this.uiDatetimePicker1 = new Sunny.UI.UIDatetimePicker();
            this.uiColorPicker1 = new Sunny.UI.UIColorPicker();
            this.uiLine7 = new Sunny.UI.UILine();
            this.uiLine6 = new Sunny.UI.UILine();
            this.uiTimePicker1 = new Sunny.UI.UITimePicker();
            this.uiLine3 = new Sunny.UI.UILine();
            this.uiLine2 = new Sunny.UI.UILine();
            this.uiDatePicker1 = new Sunny.UI.UIDatePicker();
            this.uiComboBox2 = new Sunny.UI.UIComboBox();
            this.uiComboBox1 = new Sunny.UI.UIComboBox();
            this.uiDatePicker2 = new Sunny.UI.UIDatePicker();
            this.uiDatePicker3 = new Sunny.UI.UIDatePicker();
            this.uiLine4 = new Sunny.UI.UILine();
            this.uiComboDataGridView1 = new Sunny.UI.UIComboDataGridView();
            this.uiLine5 = new Sunny.UI.UILine();
            this.uiComboBox3 = new Sunny.UI.UIComboBox();
            this.uiComboBox4 = new Sunny.UI.UIComboBox();
            this.uiComboDataGridView2 = new Sunny.UI.UIComboDataGridView();
            this.uiLine9 = new Sunny.UI.UILine();
            this.uiToolTip1 = new Sunny.UI.UIToolTip(this.components);
            this.uiLine10 = new Sunny.UI.UILine();
            this.uiNumPadTextBox1 = new Sunny.UI.UINumPadTextBox();
            this.uiNumPadTextBox2 = new Sunny.UI.UINumPadTextBox();
            this.uiNumPadTextBox3 = new Sunny.UI.UINumPadTextBox();
            this.uiNumPadTextBox4 = new Sunny.UI.UINumPadTextBox();
            this.SuspendLayout();
            // 
            // uiComboTreeView3
            // 
            this.uiComboTreeView3.CheckBoxes = true;
            this.uiComboTreeView3.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.uiComboTreeView3.FillColor = System.Drawing.Color.White;
            this.uiComboTreeView3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiComboTreeView3.Location = new System.Drawing.Point(544, 373);
            this.uiComboTreeView3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboTreeView3.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboTreeView3.Name = "uiComboTreeView3";
            treeNode65.Name = "节点0";
            treeNode65.Text = "节点0";
            treeNode66.Name = "节点1";
            treeNode66.Text = "节点1";
            treeNode67.Name = "节点2";
            treeNode67.Text = "节点2";
            treeNode68.Name = "节点3";
            treeNode68.Text = "节点3";
            treeNode69.Name = "节点0";
            treeNode69.Text = "节点0";
            treeNode70.Name = "节点4";
            treeNode70.Text = "节点4";
            treeNode71.Name = "节点5";
            treeNode71.Text = "节点5";
            treeNode72.Name = "节点6";
            treeNode72.Text = "节点6";
            treeNode73.Name = "节点7";
            treeNode73.Text = "节点7";
            treeNode74.Name = "节点1";
            treeNode74.Text = "节点1";
            treeNode75.Name = "节点2";
            treeNode75.Text = "节点2";
            treeNode76.Name = "节点3";
            treeNode76.Text = "节点3";
            this.uiComboTreeView3.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode69,
            treeNode74,
            treeNode75,
            treeNode76});
            this.uiComboTreeView3.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboTreeView3.ShowLines = true;
            this.uiComboTreeView3.Size = new System.Drawing.Size(150, 29);
            this.uiComboTreeView3.TabIndex = 67;
            this.uiComboTreeView3.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboTreeView3.Watermark = "";
            // 
            // uiComboTreeView4
            // 
            this.uiComboTreeView4.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.uiComboTreeView4.FillColor = System.Drawing.Color.White;
            this.uiComboTreeView4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiComboTreeView4.Location = new System.Drawing.Point(386, 373);
            this.uiComboTreeView4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboTreeView4.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboTreeView4.Name = "uiComboTreeView4";
            treeNode77.Name = "节点0";
            treeNode77.Text = "节点00";
            treeNode78.Name = "节点1";
            treeNode78.Text = "节点01";
            treeNode79.Name = "节点2";
            treeNode79.Text = "节点02";
            treeNode80.Name = "节点3";
            treeNode80.Text = "节点03";
            treeNode81.Name = "节点0";
            treeNode81.Text = "节点0";
            treeNode82.Name = "节点4";
            treeNode82.Text = "节点11";
            treeNode83.Name = "节点5";
            treeNode83.Text = "节点12";
            treeNode84.Name = "节点6";
            treeNode84.Text = "节点13";
            treeNode85.Name = "节点7";
            treeNode85.Text = "节点14";
            treeNode86.Name = "节点1";
            treeNode86.Text = "节点1";
            treeNode87.Name = "节点2";
            treeNode87.Text = "节点2";
            treeNode88.Name = "节点3";
            treeNode88.Text = "节点3";
            this.uiComboTreeView4.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode81,
            treeNode86,
            treeNode87,
            treeNode88});
            this.uiComboTreeView4.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboTreeView4.ShowLines = true;
            this.uiComboTreeView4.Size = new System.Drawing.Size(150, 29);
            this.uiComboTreeView4.TabIndex = 66;
            this.uiComboTreeView4.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboTreeView4.Watermark = "";
            // 
            // uiComboTreeView2
            // 
            this.uiComboTreeView2.CheckBoxes = true;
            this.uiComboTreeView2.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.uiComboTreeView2.FillColor = System.Drawing.Color.White;
            this.uiComboTreeView2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiComboTreeView2.Location = new System.Drawing.Point(544, 329);
            this.uiComboTreeView2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboTreeView2.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboTreeView2.Name = "uiComboTreeView2";
            treeNode89.Name = "节点0";
            treeNode89.Text = "节点0";
            treeNode90.Name = "节点1";
            treeNode90.Text = "节点1";
            treeNode91.Name = "节点2";
            treeNode91.Text = "节点2";
            treeNode92.Name = "节点3";
            treeNode92.Text = "节点3";
            this.uiComboTreeView2.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode89,
            treeNode90,
            treeNode91,
            treeNode92});
            this.uiComboTreeView2.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboTreeView2.Size = new System.Drawing.Size(150, 29);
            this.uiComboTreeView2.TabIndex = 65;
            this.uiComboTreeView2.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboTreeView2.Watermark = "";
            this.uiComboTreeView2.NodesSelected += new Sunny.UI.UIComboTreeView.OnNodesSelected(this.uiComboTreeView2_NodesSelected);
            // 
            // uiLine1
            // 
            this.uiLine1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine1.Location = new System.Drawing.Point(386, 294);
            this.uiLine1.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine1.Name = "uiLine1";
            this.uiLine1.Size = new System.Drawing.Size(308, 20);
            this.uiLine1.TabIndex = 64;
            this.uiLine1.Text = "UIComboTreeView";
            this.uiLine1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiComboTreeView1
            // 
            this.uiComboTreeView1.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.uiComboTreeView1.FillColor = System.Drawing.Color.White;
            this.uiComboTreeView1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiComboTreeView1.Location = new System.Drawing.Point(386, 329);
            this.uiComboTreeView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboTreeView1.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboTreeView1.Name = "uiComboTreeView1";
            treeNode93.Name = "节点0";
            treeNode93.Text = "节点0";
            treeNode94.Name = "节点1";
            treeNode94.Text = "节点1";
            treeNode95.Name = "节点2";
            treeNode95.Text = "节点2";
            treeNode96.Name = "节点3";
            treeNode96.Text = "节点3";
            this.uiComboTreeView1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode93,
            treeNode94,
            treeNode95,
            treeNode96});
            this.uiComboTreeView1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboTreeView1.Size = new System.Drawing.Size(150, 29);
            this.uiComboTreeView1.TabIndex = 63;
            this.uiComboTreeView1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboTreeView1.Watermark = "";
            // 
            // uiLine8
            // 
            this.uiLine8.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine8.Location = new System.Drawing.Point(30, 337);
            this.uiLine8.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine8.Name = "uiLine8";
            this.uiLine8.Size = new System.Drawing.Size(308, 20);
            this.uiLine8.TabIndex = 62;
            this.uiLine8.Text = "UIDatetimePicker";
            this.uiLine8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiDatetimePicker1
            // 
            this.uiDatetimePicker1.CanEmpty = true;
            this.uiDatetimePicker1.FillColor = System.Drawing.Color.White;
            this.uiDatetimePicker1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiDatetimePicker1.Location = new System.Drawing.Point(30, 372);
            this.uiDatetimePicker1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiDatetimePicker1.MaxLength = 19;
            this.uiDatetimePicker1.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiDatetimePicker1.Name = "uiDatetimePicker1";
            this.uiDatetimePicker1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiDatetimePicker1.Size = new System.Drawing.Size(308, 29);
            this.uiDatetimePicker1.SymbolDropDown = 61555;
            this.uiDatetimePicker1.SymbolNormal = 61555;
            this.uiDatetimePicker1.TabIndex = 61;
            this.uiDatetimePicker1.Text = "2020-06-02 17:57:28";
            this.uiDatetimePicker1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiDatetimePicker1.Value = new System.DateTime(2020, 6, 2, 17, 57, 28, 203);
            this.uiDatetimePicker1.Watermark = "";
            this.uiDatetimePicker1.ValueChanged += new Sunny.UI.UIDatetimePicker.OnDateTimeChanged(this.uiDatetimePicker1_ValueChanged);
            // 
            // uiColorPicker1
            // 
            this.uiColorPicker1.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.uiColorPicker1.FillColor = System.Drawing.Color.White;
            this.uiColorPicker1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiColorPicker1.Location = new System.Drawing.Point(388, 89);
            this.uiColorPicker1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiColorPicker1.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiColorPicker1.Name = "uiColorPicker1";
            this.uiColorPicker1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiColorPicker1.Size = new System.Drawing.Size(150, 29);
            this.uiColorPicker1.TabIndex = 60;
            this.uiColorPicker1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiColorPicker1.Watermark = "";
            this.uiColorPicker1.ValueChanged += new Sunny.UI.UIColorPicker.OnColorChanged(this.uiColorPicker1_ValueChanged);
            this.uiColorPicker1.Click += new System.EventHandler(this.uiColorPicker1_Click);
            // 
            // uiLine7
            // 
            this.uiLine7.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine7.Location = new System.Drawing.Point(388, 55);
            this.uiLine7.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine7.Name = "uiLine7";
            this.uiLine7.Size = new System.Drawing.Size(306, 20);
            this.uiLine7.TabIndex = 59;
            this.uiLine7.Text = "UIColorPicker";
            this.uiLine7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine6
            // 
            this.uiLine6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine6.Location = new System.Drawing.Point(30, 416);
            this.uiLine6.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine6.Name = "uiLine6";
            this.uiLine6.Size = new System.Drawing.Size(308, 20);
            this.uiLine6.TabIndex = 58;
            this.uiLine6.Text = "UITimePicker";
            this.uiLine6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiTimePicker1
            // 
            this.uiTimePicker1.CanEmpty = true;
            this.uiTimePicker1.FillColor = System.Drawing.Color.White;
            this.uiTimePicker1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiTimePicker1.Location = new System.Drawing.Point(30, 451);
            this.uiTimePicker1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiTimePicker1.MaxLength = 8;
            this.uiTimePicker1.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiTimePicker1.Name = "uiTimePicker1";
            this.uiTimePicker1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiTimePicker1.Size = new System.Drawing.Size(150, 29);
            this.uiTimePicker1.SymbolDropDown = 61555;
            this.uiTimePicker1.SymbolNormal = 61555;
            this.uiTimePicker1.TabIndex = 57;
            this.uiTimePicker1.Text = "23:41:39";
            this.uiTimePicker1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiTimePicker1.Value = new System.DateTime(2020, 5, 29, 23, 41, 39, 684);
            this.uiTimePicker1.Watermark = "";
            this.uiTimePicker1.ValueChanged += new Sunny.UI.UITimePicker.OnDateTimeChanged(this.uiTimePicker1_ValueChanged);
            // 
            // uiLine3
            // 
            this.uiLine3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine3.Location = new System.Drawing.Point(30, 214);
            this.uiLine3.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine3.Name = "uiLine3";
            this.uiLine3.Size = new System.Drawing.Size(308, 20);
            this.uiLine3.TabIndex = 56;
            this.uiLine3.Text = "UIDatePicker";
            this.uiLine3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiLine2
            // 
            this.uiLine2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine2.Location = new System.Drawing.Point(30, 55);
            this.uiLine2.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine2.Name = "uiLine2";
            this.uiLine2.Size = new System.Drawing.Size(308, 20);
            this.uiLine2.TabIndex = 55;
            this.uiLine2.Text = "UIComboBox";
            this.uiLine2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiDatePicker1
            // 
            this.uiDatePicker1.CanEmpty = true;
            this.uiDatePicker1.DateFormat = "yyyy";
            this.uiDatePicker1.FillColor = System.Drawing.Color.White;
            this.uiDatePicker1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiDatePicker1.Location = new System.Drawing.Point(30, 249);
            this.uiDatePicker1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiDatePicker1.MaxLength = 4;
            this.uiDatePicker1.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiDatePicker1.Name = "uiDatePicker1";
            this.uiDatePicker1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiDatePicker1.ShowToday = true;
            this.uiDatePicker1.ShowType = Sunny.UI.UIDateType.Year;
            this.uiDatePicker1.Size = new System.Drawing.Size(150, 29);
            this.uiDatePicker1.SymbolDropDown = 61555;
            this.uiDatePicker1.SymbolNormal = 61555;
            this.uiDatePicker1.TabIndex = 54;
            this.uiDatePicker1.Text = "2020";
            this.uiDatePicker1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiDatePicker1.Value = new System.DateTime(2020, 4, 16, 0, 0, 0, 0);
            this.uiDatePicker1.Watermark = "";
            this.uiDatePicker1.ValueChanged += new Sunny.UI.UIDatePicker.OnDateTimeChanged(this.uiDatePicker1_ValueChanged);
            // 
            // uiComboBox2
            // 
            this.uiComboBox2.DataSource = null;
            this.uiComboBox2.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.uiComboBox2.DropDownWidth = 300;
            this.uiComboBox2.FillColor = System.Drawing.Color.White;
            this.uiComboBox2.FilterMaxCount = 50;
            this.uiComboBox2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiComboBox2.Location = new System.Drawing.Point(188, 89);
            this.uiComboBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboBox2.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboBox2.Name = "uiComboBox2";
            this.uiComboBox2.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboBox2.ShowClearButton = true;
            this.uiComboBox2.Size = new System.Drawing.Size(150, 29);
            this.uiComboBox2.TabIndex = 53;
            this.uiComboBox2.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboBox2.Watermark = "";
            // 
            // uiComboBox1
            // 
            this.uiComboBox1.DataSource = null;
            this.uiComboBox1.FillColor = System.Drawing.Color.White;
            this.uiComboBox1.FilterMaxCount = 50;
            this.uiComboBox1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiComboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16"});
            this.uiComboBox1.Location = new System.Drawing.Point(30, 90);
            this.uiComboBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboBox1.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboBox1.Name = "uiComboBox1";
            this.uiComboBox1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboBox1.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiComboBox1.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom;
            this.uiComboBox1.Size = new System.Drawing.Size(150, 29);
            this.uiComboBox1.TabIndex = 52;
            this.uiComboBox1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboBox1.Watermark = "水印文字";
            this.uiComboBox1.TipsClick += new System.EventHandler(this.uiComboBox1_TipsClick);
            // 
            // uiDatePicker2
            // 
            this.uiDatePicker2.CanEmpty = true;
            this.uiDatePicker2.DateFormat = "yyyy-MM";
            this.uiDatePicker2.FillColor = System.Drawing.Color.White;
            this.uiDatePicker2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiDatePicker2.Location = new System.Drawing.Point(188, 249);
            this.uiDatePicker2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiDatePicker2.MaxLength = 7;
            this.uiDatePicker2.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiDatePicker2.Name = "uiDatePicker2";
            this.uiDatePicker2.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiDatePicker2.ShowToday = true;
            this.uiDatePicker2.ShowType = Sunny.UI.UIDateType.YearMonth;
            this.uiDatePicker2.Size = new System.Drawing.Size(150, 29);
            this.uiDatePicker2.SymbolDropDown = 61555;
            this.uiDatePicker2.SymbolNormal = 61555;
            this.uiDatePicker2.TabIndex = 71;
            this.uiDatePicker2.Text = "2020-04";
            this.uiDatePicker2.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiDatePicker2.Value = new System.DateTime(2020, 4, 16, 0, 0, 0, 0);
            this.uiDatePicker2.Watermark = "";
            // 
            // uiDatePicker3
            // 
            this.uiDatePicker3.CanEmpty = true;
            this.uiDatePicker3.FillColor = System.Drawing.Color.White;
            this.uiDatePicker3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiDatePicker3.Location = new System.Drawing.Point(30, 293);
            this.uiDatePicker3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiDatePicker3.MaxLength = 10;
            this.uiDatePicker3.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiDatePicker3.Name = "uiDatePicker3";
            this.uiDatePicker3.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiDatePicker3.ShowToday = true;
            this.uiDatePicker3.Size = new System.Drawing.Size(150, 29);
            this.uiDatePicker3.SymbolDropDown = 61555;
            this.uiDatePicker3.SymbolNormal = 61555;
            this.uiDatePicker3.TabIndex = 72;
            this.uiDatePicker3.Text = "2020-04-16";
            this.uiDatePicker3.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiDatePicker3.Value = new System.DateTime(2020, 4, 16, 0, 0, 0, 0);
            this.uiDatePicker3.Watermark = "";
            this.uiDatePicker3.ValueChanged += new Sunny.UI.UIDatePicker.OnDateTimeChanged(this.uiDatePicker3_ValueChanged);
            // 
            // uiLine4
            // 
            this.uiLine4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine4.Location = new System.Drawing.Point(386, 134);
            this.uiLine4.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine4.Name = "uiLine4";
            this.uiLine4.Size = new System.Drawing.Size(308, 20);
            this.uiLine4.TabIndex = 73;
            this.uiLine4.Text = "UIComboDataGridView";
            this.uiLine4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiComboDataGridView1
            // 
            this.uiComboDataGridView1.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.uiComboDataGridView1.FillColor = System.Drawing.Color.White;
            this.uiComboDataGridView1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiComboDataGridView1.Location = new System.Drawing.Point(386, 169);
            this.uiComboDataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboDataGridView1.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboDataGridView1.Name = "uiComboDataGridView1";
            this.uiComboDataGridView1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboDataGridView1.Size = new System.Drawing.Size(308, 29);
            this.uiComboDataGridView1.TabIndex = 74;
            this.uiComboDataGridView1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboDataGridView1.Watermark = "";
            this.uiComboDataGridView1.SelectIndexChange += new Sunny.UI.UIDataGridView.OnSelectIndexChange(this.uiComboDataGridView1_SelectIndexChange_1);
            this.uiComboDataGridView1.ValueChanged += new Sunny.UI.UIComboDataGridView.OnValueChanged(this.uiComboDataGridView1_ValueChanged);
            // 
            // uiLine5
            // 
            this.uiLine5.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine5.Location = new System.Drawing.Point(30, 134);
            this.uiLine5.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine5.Name = "uiLine5";
            this.uiLine5.Size = new System.Drawing.Size(308, 20);
            this.uiLine5.TabIndex = 77;
            this.uiLine5.Text = "UIComboBox (ShowFilter)";
            this.uiLine5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiComboBox3
            // 
            this.uiComboBox3.DataSource = null;
            this.uiComboBox3.DropDownWidth = 300;
            this.uiComboBox3.FillColor = System.Drawing.Color.White;
            this.uiComboBox3.FilterMaxCount = 50;
            this.uiComboBox3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiComboBox3.Location = new System.Drawing.Point(188, 168);
            this.uiComboBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboBox3.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboBox3.Name = "uiComboBox3";
            this.uiComboBox3.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboBox3.ShowFilter = true;
            this.uiComboBox3.Size = new System.Drawing.Size(150, 29);
            this.uiComboBox3.TabIndex = 76;
            this.uiComboBox3.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboBox3.Watermark = "";
            this.uiComboBox3.SelectedValueChanged += new System.EventHandler(this.uiComboBox3_SelectedValueChanged);
            // 
            // uiComboBox4
            // 
            this.uiComboBox4.DataSource = null;
            this.uiComboBox4.FillColor = System.Drawing.Color.White;
            this.uiComboBox4.FilterMaxCount = 50;
            this.uiComboBox4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiComboBox4.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "111",
            "112",
            "113",
            "114",
            "115",
            "116"});
            this.uiComboBox4.Location = new System.Drawing.Point(30, 169);
            this.uiComboBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboBox4.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboBox4.Name = "uiComboBox4";
            this.uiComboBox4.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboBox4.RadiusSides = Sunny.UI.UICornerRadiusSides.None;
            this.uiComboBox4.RectSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom;
            this.uiComboBox4.ShowFilter = true;
            this.uiComboBox4.Size = new System.Drawing.Size(150, 29);
            this.uiComboBox4.TabIndex = 75;
            this.uiComboBox4.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboBox4.Watermark = "水印文字";
            this.uiComboBox4.SelectedValueChanged += new System.EventHandler(this.uiComboBox4_SelectedValueChanged);
            // 
            // uiComboDataGridView2
            // 
            this.uiComboDataGridView2.DropDownStyle = Sunny.UI.UIDropDownStyle.DropDownList;
            this.uiComboDataGridView2.FillColor = System.Drawing.Color.White;
            this.uiComboDataGridView2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiComboDataGridView2.Location = new System.Drawing.Point(386, 249);
            this.uiComboDataGridView2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiComboDataGridView2.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiComboDataGridView2.Name = "uiComboDataGridView2";
            this.uiComboDataGridView2.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiComboDataGridView2.Size = new System.Drawing.Size(308, 29);
            this.uiComboDataGridView2.TabIndex = 79;
            this.uiComboDataGridView2.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiComboDataGridView2.Watermark = "";
            this.uiComboDataGridView2.ValueChanged += new Sunny.UI.UIComboDataGridView.OnValueChanged(this.uiComboDataGridView2_ValueChanged);
            // 
            // uiLine9
            // 
            this.uiLine9.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine9.Location = new System.Drawing.Point(386, 214);
            this.uiLine9.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine9.Name = "uiLine9";
            this.uiLine9.Size = new System.Drawing.Size(308, 20);
            this.uiLine9.TabIndex = 78;
            this.uiLine9.Text = "UIComboDataGridView (MultiSelect)";
            this.uiLine9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiToolTip1
            // 
            this.uiToolTip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.uiToolTip1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(239)))), ((int)(((byte)(239)))));
            this.uiToolTip1.OwnerDraw = true;
            // 
            // uiLine10
            // 
            this.uiLine10.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLine10.Location = new System.Drawing.Point(386, 416);
            this.uiLine10.MinimumSize = new System.Drawing.Size(16, 16);
            this.uiLine10.Name = "uiLine10";
            this.uiLine10.Size = new System.Drawing.Size(308, 20);
            this.uiLine10.TabIndex = 80;
            this.uiLine10.Text = "UINumPadTextBox";
            this.uiLine10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiNumPadTextBox1
            // 
            this.uiNumPadTextBox1.FillColor = System.Drawing.Color.White;
            this.uiNumPadTextBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiNumPadTextBox1.Location = new System.Drawing.Point(386, 451);
            this.uiNumPadTextBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiNumPadTextBox1.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiNumPadTextBox1.Name = "uiNumPadTextBox1";
            this.uiNumPadTextBox1.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiNumPadTextBox1.Size = new System.Drawing.Size(150, 29);
            this.uiNumPadTextBox1.TabIndex = 81;
            this.uiNumPadTextBox1.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiNumPadTextBox1.Watermark = "";
            // 
            // uiNumPadTextBox2
            // 
            this.uiNumPadTextBox2.FillColor = System.Drawing.Color.White;
            this.uiNumPadTextBox2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiNumPadTextBox2.Location = new System.Drawing.Point(544, 451);
            this.uiNumPadTextBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiNumPadTextBox2.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiNumPadTextBox2.Name = "uiNumPadTextBox2";
            this.uiNumPadTextBox2.NumPadType = Sunny.UI.NumPadType.Integer;
            this.uiNumPadTextBox2.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiNumPadTextBox2.Size = new System.Drawing.Size(150, 29);
            this.uiNumPadTextBox2.TabIndex = 82;
            this.uiNumPadTextBox2.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiNumPadTextBox2.Watermark = "";
            // 
            // uiNumPadTextBox3
            // 
            this.uiNumPadTextBox3.FillColor = System.Drawing.Color.White;
            this.uiNumPadTextBox3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiNumPadTextBox3.Location = new System.Drawing.Point(544, 495);
            this.uiNumPadTextBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiNumPadTextBox3.MaxLength = 18;
            this.uiNumPadTextBox3.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiNumPadTextBox3.Name = "uiNumPadTextBox3";
            this.uiNumPadTextBox3.NumPadType = Sunny.UI.NumPadType.IDNumber;
            this.uiNumPadTextBox3.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiNumPadTextBox3.Size = new System.Drawing.Size(150, 29);
            this.uiNumPadTextBox3.TabIndex = 84;
            this.uiNumPadTextBox3.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiNumPadTextBox3.Watermark = "";
            // 
            // uiNumPadTextBox4
            // 
            this.uiNumPadTextBox4.FillColor = System.Drawing.Color.White;
            this.uiNumPadTextBox4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uiNumPadTextBox4.Location = new System.Drawing.Point(386, 495);
            this.uiNumPadTextBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiNumPadTextBox4.MinimumSize = new System.Drawing.Size(63, 0);
            this.uiNumPadTextBox4.Name = "uiNumPadTextBox4";
            this.uiNumPadTextBox4.NumPadType = Sunny.UI.NumPadType.Double;
            this.uiNumPadTextBox4.Padding = new System.Windows.Forms.Padding(0, 0, 30, 2);
            this.uiNumPadTextBox4.Size = new System.Drawing.Size(150, 29);
            this.uiNumPadTextBox4.TabIndex = 83;
            this.uiNumPadTextBox4.TextAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.uiNumPadTextBox4.Watermark = "";
            // 
            // FCombobox
            // 
            this.AllowShowTitle = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(765, 593);
            this.Controls.Add(this.uiNumPadTextBox3);
            this.Controls.Add(this.uiNumPadTextBox4);
            this.Controls.Add(this.uiNumPadTextBox2);
            this.Controls.Add(this.uiNumPadTextBox1);
            this.Controls.Add(this.uiLine10);
            this.Controls.Add(this.uiComboDataGridView2);
            this.Controls.Add(this.uiLine9);
            this.Controls.Add(this.uiLine5);
            this.Controls.Add(this.uiComboBox3);
            this.Controls.Add(this.uiComboBox4);
            this.Controls.Add(this.uiComboDataGridView1);
            this.Controls.Add(this.uiLine4);
            this.Controls.Add(this.uiDatePicker3);
            this.Controls.Add(this.uiDatePicker2);
            this.Controls.Add(this.uiComboTreeView3);
            this.Controls.Add(this.uiComboTreeView4);
            this.Controls.Add(this.uiComboTreeView2);
            this.Controls.Add(this.uiLine1);
            this.Controls.Add(this.uiComboTreeView1);
            this.Controls.Add(this.uiLine8);
            this.Controls.Add(this.uiDatetimePicker1);
            this.Controls.Add(this.uiColorPicker1);
            this.Controls.Add(this.uiLine7);
            this.Controls.Add(this.uiLine6);
            this.Controls.Add(this.uiTimePicker1);
            this.Controls.Add(this.uiLine3);
            this.Controls.Add(this.uiLine2);
            this.Controls.Add(this.uiDatePicker1);
            this.Controls.Add(this.uiComboBox2);
            this.Controls.Add(this.uiComboBox1);
            this.Name = "FCombobox";
            this.Padding = new System.Windows.Forms.Padding(0, 35, 0, 0);
            this.ShowTitle = true;
            this.Symbol = 61776;
            this.Text = "Combobox";
            this.ResumeLayout(false);

        }

        #endregion
        private UIComboTreeView uiComboTreeView3;
        private UIComboTreeView uiComboTreeView4;
        private UIComboTreeView uiComboTreeView2;
        private UILine uiLine1;
        private UIComboTreeView uiComboTreeView1;
        private UILine uiLine8;
        private UIDatetimePicker uiDatetimePicker1;
        private UIColorPicker uiColorPicker1;
        private UILine uiLine7;
        private UILine uiLine6;
        private UITimePicker uiTimePicker1;
        private UILine uiLine3;
        private UILine uiLine2;
        private UIDatePicker uiDatePicker1;
        private UIComboBox uiComboBox2;
        private UIComboBox uiComboBox1;
        private UIDatePicker uiDatePicker2;
        private UIDatePicker uiDatePicker3;
        private UILine uiLine4;
        private UIComboDataGridView uiComboDataGridView1;
        private UILine uiLine5;
        private UIComboBox uiComboBox3;
        private UIComboBox uiComboBox4;
        private UIComboDataGridView uiComboDataGridView2;
        private UILine uiLine9;
        private UIToolTip uiToolTip1;
        private UILine uiLine10;
        private UINumPadTextBox uiNumPadTextBox1;
        private UINumPadTextBox uiNumPadTextBox2;
        private UINumPadTextBox uiNumPadTextBox3;
        private UINumPadTextBox uiNumPadTextBox4;
    }
}