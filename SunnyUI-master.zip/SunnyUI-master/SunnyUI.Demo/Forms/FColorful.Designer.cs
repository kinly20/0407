﻿
namespace Sunny.UI.Demo
{
    partial class FColorful
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uiPanel1 = new Sunny.UI.UIPanel();
            this.uiPanel2 = new Sunny.UI.UIPanel();
            this.uiPanel3 = new Sunny.UI.UIPanel();
            this.uiPanel4 = new Sunny.UI.UIPanel();
            this.uiPanel5 = new Sunny.UI.UIPanel();
            this.uiPanel6 = new Sunny.UI.UIPanel();
            this.uiPanel7 = new Sunny.UI.UIPanel();
            this.uiPanel8 = new Sunny.UI.UIPanel();
            this.uiPanel9 = new Sunny.UI.UIPanel();
            this.uiPanel10 = new Sunny.UI.UIPanel();
            this.uiLabel1 = new Sunny.UI.UILabel();
            this.uiPanel11 = new Sunny.UI.UIPanel();
            this.uiLabel2 = new Sunny.UI.UILabel();
            this.SuspendLayout();
            // 
            // uiPanel1
            // 
            this.uiPanel1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(190)))), ((int)(((byte)(172)))));
            this.uiPanel1.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiPanel1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel1.ForeColor = System.Drawing.Color.White;
            this.uiPanel1.Location = new System.Drawing.Point(173, 56);
            this.uiPanel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel1.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel1.Name = "uiPanel1";
            this.uiPanel1.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(190)))), ((int)(((byte)(172)))));
            this.uiPanel1.Size = new System.Drawing.Size(120, 100);
            this.uiPanel1.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel1.StyleCustomMode = true;
            this.uiPanel1.TabIndex = 0;
            this.uiPanel1.Text = "蓝绿色";
            this.uiPanel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel1.Click += new System.EventHandler(this.uiPanel1_Click);
            // 
            // uiPanel2
            // 
            this.uiPanel2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.uiPanel2.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiPanel2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel2.ForeColor = System.Drawing.Color.White;
            this.uiPanel2.Location = new System.Drawing.Point(323, 56);
            this.uiPanel2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel2.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel2.Name = "uiPanel2";
            this.uiPanel2.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(184)))), ((int)(((byte)(0)))));
            this.uiPanel2.Size = new System.Drawing.Size(120, 100);
            this.uiPanel2.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel2.StyleCustomMode = true;
            this.uiPanel2.TabIndex = 1;
            this.uiPanel2.Text = "橙色";
            this.uiPanel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel2.Click += new System.EventHandler(this.uiPanel1_Click);
            // 
            // uiPanel3
            // 
            this.uiPanel3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(190)))), ((int)(((byte)(60)))));
            this.uiPanel3.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiPanel3.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel3.ForeColor = System.Drawing.Color.White;
            this.uiPanel3.Location = new System.Drawing.Point(473, 174);
            this.uiPanel3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel3.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel3.Name = "uiPanel3";
            this.uiPanel3.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(121)))), ((int)(((byte)(190)))), ((int)(((byte)(60)))));
            this.uiPanel3.Size = new System.Drawing.Size(120, 100);
            this.uiPanel3.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel3.StyleCustomMode = true;
            this.uiPanel3.TabIndex = 3;
            this.uiPanel3.Text = "绿色";
            this.uiPanel3.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel3.Click += new System.EventHandler(this.uiPanel1_Click);
            // 
            // uiPanel4
            // 
            this.uiPanel4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(100)))), ((int)(((byte)(80)))));
            this.uiPanel4.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiPanel4.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel4.ForeColor = System.Drawing.Color.White;
            this.uiPanel4.Location = new System.Drawing.Point(623, 174);
            this.uiPanel4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel4.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel4.Name = "uiPanel4";
            this.uiPanel4.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(100)))), ((int)(((byte)(80)))));
            this.uiPanel4.Size = new System.Drawing.Size(120, 100);
            this.uiPanel4.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel4.StyleCustomMode = true;
            this.uiPanel4.TabIndex = 2;
            this.uiPanel4.Text = "咖啡色";
            this.uiPanel4.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel4.Click += new System.EventHandler(this.uiPanel1_Click);
            // 
            // uiPanel5
            // 
            this.uiPanel5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(98)))), ((int)(((byte)(161)))));
            this.uiPanel5.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiPanel5.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel5.ForeColor = System.Drawing.Color.White;
            this.uiPanel5.Location = new System.Drawing.Point(623, 56);
            this.uiPanel5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel5.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel5.Name = "uiPanel5";
            this.uiPanel5.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(98)))), ((int)(((byte)(161)))));
            this.uiPanel5.Size = new System.Drawing.Size(120, 100);
            this.uiPanel5.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel5.StyleCustomMode = true;
            this.uiPanel5.TabIndex = 4;
            this.uiPanel5.Text = "粉色";
            this.uiPanel5.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel5.Click += new System.EventHandler(this.uiPanel1_Click);
            // 
            // uiPanel6
            // 
            this.uiPanel6.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.uiPanel6.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiPanel6.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel6.ForeColor = System.Drawing.Color.White;
            this.uiPanel6.Location = new System.Drawing.Point(473, 56);
            this.uiPanel6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel6.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel6.Name = "uiPanel6";
            this.uiPanel6.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(87)))), ((int)(((byte)(34)))));
            this.uiPanel6.Size = new System.Drawing.Size(120, 100);
            this.uiPanel6.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel6.StyleCustomMode = true;
            this.uiPanel6.TabIndex = 8;
            this.uiPanel6.Text = "红色";
            this.uiPanel6.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel6.Click += new System.EventHandler(this.uiPanel1_Click);
            // 
            // uiPanel7
            // 
            this.uiPanel7.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(126)))), ((int)(((byte)(164)))));
            this.uiPanel7.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiPanel7.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel7.ForeColor = System.Drawing.Color.White;
            this.uiPanel7.Location = new System.Drawing.Point(323, 174);
            this.uiPanel7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel7.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel7.Name = "uiPanel7";
            this.uiPanel7.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(126)))), ((int)(((byte)(164)))));
            this.uiPanel7.Size = new System.Drawing.Size(120, 100);
            this.uiPanel7.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel7.StyleCustomMode = true;
            this.uiPanel7.TabIndex = 7;
            this.uiPanel7.Text = "蓝灰色";
            this.uiPanel7.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel7.Click += new System.EventHandler(this.uiPanel1_Click);
            // 
            // uiPanel8
            // 
            this.uiPanel8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.uiPanel8.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiPanel8.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel8.ForeColor = System.Drawing.Color.White;
            this.uiPanel8.Location = new System.Drawing.Point(173, 174);
            this.uiPanel8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel8.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel8.Name = "uiPanel8";
            this.uiPanel8.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(188)))), ((int)(((byte)(212)))));
            this.uiPanel8.Size = new System.Drawing.Size(120, 100);
            this.uiPanel8.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel8.StyleCustomMode = true;
            this.uiPanel8.TabIndex = 6;
            this.uiPanel8.Text = "蓝色";
            this.uiPanel8.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel8.Click += new System.EventHandler(this.uiPanel1_Click);
            // 
            // uiPanel9
            // 
            this.uiPanel9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.uiPanel9.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiPanel9.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel9.ForeColor = System.Drawing.Color.White;
            this.uiPanel9.Location = new System.Drawing.Point(23, 174);
            this.uiPanel9.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel9.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel9.Name = "uiPanel9";
            this.uiPanel9.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.uiPanel9.Size = new System.Drawing.Size(120, 100);
            this.uiPanel9.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel9.StyleCustomMode = true;
            this.uiPanel9.TabIndex = 5;
            this.uiPanel9.Text = "紫色";
            this.uiPanel9.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel9.Click += new System.EventHandler(this.uiPanel1_Click);
            // 
            // uiPanel10
            // 
            this.uiPanel10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.uiPanel10.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiPanel10.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel10.ForeColor = System.Drawing.Color.White;
            this.uiPanel10.Location = new System.Drawing.Point(23, 56);
            this.uiPanel10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel10.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel10.Name = "uiPanel10";
            this.uiPanel10.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(150)))), ((int)(((byte)(136)))));
            this.uiPanel10.Size = new System.Drawing.Size(120, 100);
            this.uiPanel10.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel10.StyleCustomMode = true;
            this.uiPanel10.TabIndex = 9;
            this.uiPanel10.Text = "墨绿色";
            this.uiPanel10.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel10.Click += new System.EventHandler(this.uiPanel1_Click);
            // 
            // uiLabel1
            // 
            this.uiLabel1.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel1.Location = new System.Drawing.Point(23, 297);
            this.uiLabel1.Name = "uiLabel1";
            this.uiLabel1.Size = new System.Drawing.Size(698, 23);
            this.uiLabel1.TabIndex = 10;
            this.uiLabel1.Text = "多彩主题，以颜色深色，文字白色为主，主题配色自动计算，不能保证所有颜色显示效果";
            this.uiLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // uiPanel11
            // 
            this.uiPanel11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.uiPanel11.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(249)))), ((int)(((byte)(255)))));
            this.uiPanel11.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiPanel11.ForeColor = System.Drawing.Color.White;
            this.uiPanel11.Location = new System.Drawing.Point(23, 340);
            this.uiPanel11.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.uiPanel11.MinimumSize = new System.Drawing.Size(1, 1);
            this.uiPanel11.Name = "uiPanel11";
            this.uiPanel11.RectColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(58)))), ((int)(((byte)(183)))));
            this.uiPanel11.Size = new System.Drawing.Size(120, 100);
            this.uiPanel11.Style = Sunny.UI.UIStyle.Custom;
            this.uiPanel11.StyleCustomMode = true;
            this.uiPanel11.TabIndex = 11;
            this.uiPanel11.Text = "随机颜色";
            this.uiPanel11.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.uiPanel11.Click += new System.EventHandler(this.uiPanel11_Click);
            // 
            // uiLabel2
            // 
            this.uiLabel2.Font = new System.Drawing.Font("微软雅黑", 12F);
            this.uiLabel2.Location = new System.Drawing.Point(23, 457);
            this.uiLabel2.Name = "uiLabel2";
            this.uiLabel2.Size = new System.Drawing.Size(172, 23);
            this.uiLabel2.TabIndex = 12;
            this.uiLabel2.Text = "RGB: 255, 255, 255 ";
            this.uiLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FColorful
            // 
            this.AllowShowTitle = true;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(776, 543);
            this.Controls.Add(this.uiLabel2);
            this.Controls.Add(this.uiPanel11);
            this.Controls.Add(this.uiLabel1);
            this.Controls.Add(this.uiPanel10);
            this.Controls.Add(this.uiPanel6);
            this.Controls.Add(this.uiPanel7);
            this.Controls.Add(this.uiPanel8);
            this.Controls.Add(this.uiPanel9);
            this.Controls.Add(this.uiPanel5);
            this.Controls.Add(this.uiPanel3);
            this.Controls.Add(this.uiPanel4);
            this.Controls.Add(this.uiPanel2);
            this.Controls.Add(this.uiPanel1);
            this.Name = "FColorful";
            this.Padding = new System.Windows.Forms.Padding(0, 35, 0, 0);
            this.PageIndex = 999;
            this.ShowTitle = true;
            this.Text = "多彩主题";
            this.ResumeLayout(false);

        }

        #endregion

        private UIPanel uiPanel1;
        private UIPanel uiPanel2;
        private UIPanel uiPanel3;
        private UIPanel uiPanel4;
        private UIPanel uiPanel5;
        private UIPanel uiPanel6;
        private UIPanel uiPanel7;
        private UIPanel uiPanel8;
        private UIPanel uiPanel9;
        private UIPanel uiPanel10;
        private UILabel uiLabel1;
        private UIPanel uiPanel11;
        private UILabel uiLabel2;
    }
}