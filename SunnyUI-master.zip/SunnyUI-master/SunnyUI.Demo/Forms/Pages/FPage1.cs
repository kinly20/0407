﻿namespace Sunny.UI.Demo
{
    public partial class FPage1 : UIPage
    {
        public FPage1()
        {
            InitializeComponent();
        }
    }
}