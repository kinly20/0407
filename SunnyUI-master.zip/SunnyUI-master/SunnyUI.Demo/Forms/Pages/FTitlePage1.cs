﻿namespace Sunny.UI.Demo
{
    public partial class FTitlePage1 : UIPage
    {
        public FTitlePage1()
        {
            InitializeComponent();
        }
    }
}