﻿namespace Sunny.UI.Demo
{
    public partial class FTitlePage3 : UIPage
    {
        public FTitlePage3()
        {
            InitializeComponent();
        }
    }
}