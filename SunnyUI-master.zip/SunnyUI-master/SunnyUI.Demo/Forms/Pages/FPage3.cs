﻿namespace Sunny.UI.Demo
{
    public partial class FPage3 : UIPage
    {
        public FPage3()
        {
            InitializeComponent();
        }
    }
}