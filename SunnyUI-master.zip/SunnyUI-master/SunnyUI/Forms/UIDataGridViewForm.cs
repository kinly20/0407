﻿namespace Sunny.UI
{
    public partial class UIDataGridViewForm : UIPage
    {
        public UIDataGridViewForm()
        {
            InitializeComponent();
        }
    }
}
